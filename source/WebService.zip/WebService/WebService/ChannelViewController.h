//
//  ChannelViewController.h
//  WebService
//
//  Created by apple  on 13-3-5.
//  Copyright (c) 2013年 rang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ServiceHelper.h"
#import "SoapHelper.h"

@interface ChannelViewController : UITableViewController<MBProgressHUDDelegate,ServiceHelperDelegate>{
    NSArray *channelArray;
    ServiceHelper *helper;
    MBProgressHUD *HUD;
}

@property (nonatomic,copy) NSString *stationID;
@end
