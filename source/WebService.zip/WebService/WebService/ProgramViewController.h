//
//  ProgramViewController.h
//  WebService
//
//  Created by apple  on 13-3-5.
//  Copyright (c) 2013年 rang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ServiceHelper.h"
#import "SoapHelper.h"
@interface ProgramViewController : UITableViewController<MBProgressHUDDelegate,ServiceHelperDelegate>{
    NSArray *programArray;
    ServiceHelper *helper;
    MBProgressHUD *HUD;
}

@property (nonatomic,copy) NSString *channelID;

@end
