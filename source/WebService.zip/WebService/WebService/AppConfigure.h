//
//  AppConfigure.h
//  HttpRequest
//
//  Created by rang on 12-11-8.
//
//
//

//webservice配置
#define defaultWebServiceUrl @"http://webservice.webxml.com.cn/webservices/ChinaTVprogramWebService.asmx"
#define defaultWebServiceNameSpace @"http://WebXml.com.cn/"
