//
//  ChannelViewController.m
//  WebService
//
//  Created by apple  on 13-3-5.
//  Copyright (c) 2013年 rang. All rights reserved.
//

#import "ChannelViewController.h"
#import "ProgramViewController.h"

@interface ChannelViewController ()

@end

@implementation ChannelViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
//开始加载动画
-(void)startLoadAnimation:(NSString*)strTitle{
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
	[self.navigationController.view addSubview:HUD];
    //[self.view addSubview:HUD];
	
	HUD.dimBackground = YES;
    //HUD.color=[UIColor redColor];
	HUD.labelText = strTitle;
	//HUD.delegate = self;
    [HUD show:YES];
}
#pragma mark -
#pragma mark MBProgressHUDDelegate methods
- (void)hudWasHidden:(MBProgressHUD *)hud {
	// Remove HUD from screen when the HUD was hidded
	[HUD removeFromSuperview];
	[HUD release];
	HUD = nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"频道";
    helper = [[ServiceHelper alloc] initWithDelegate:self];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:self.stationID,@"theTVstationID", nil];
    NSArray *ay = [NSArray arrayWithObject:dic];
    NSString *soapMsg=[SoapHelper arrayToDefaultSoapMessage:ay methodName:@"getTVchannelDataSet"];
    [helper asynServiceMethod:@"getTVchannelDataSet" SoapMessage:soapMsg nodeName:@"TvChanne"];
}
#pragma mark 异步请求结果
-(void) startRequest{
    [self startLoadAnimation:@"loading..."];
}

-(void)finishSuccessRequest:(NSMutableArray*)xml{
    
    //将xml使用SoapXmlParseHelper类转换成想要的结果
    
    //NSLog(@"异步请求返回的xml:%@",xml);
    channelArray = [[NSArray alloc] initWithArray:xml];
    [HUD hide:YES];
    [self.tableView reloadData];
}
-(void)finishFailRequest:(NSError*)error{
    NSLog(@"异步请发生失败:%@\n",[error description]);
    [HUD hide:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [channelArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    cell.textLabel.text = [[channelArray objectAtIndex:indexPath.row] objectForKey:@"tvChannel"];
    
    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    ProgramViewController *program = [segue destinationViewController];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    program.channelID = [[channelArray objectAtIndex:indexPath.row] objectForKey:@"tvChannelID"];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

@end
